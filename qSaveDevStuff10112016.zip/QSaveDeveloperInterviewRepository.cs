

//: DISCLAIMER. Kevin Citron.
//: This code has not been tested. I wrote this stuff,after only, 4 hours of 
//: perusing/exploring the world of #C/ASP.WEB
//: Further more, views were not developed to support this backend code,
//: Also, this code was written using a TextEditor, TECHNICAL Problems
//: I'm sure, there are things missing here.
//: Chris, I'm sure you get the point.

using System;
using System.Collections.Generic;


namespace QSaveApp.DataAcessLayer {

    public class QSaveDeveloperInterviewRepository : QSaveDeveloperInterviewRepository, IDisposable {

        public QSaveDeveloperInterviewRepository()
        {
            //: Do some CTOR stuff
        }

        public IEnumerable<QSaveDeveloperInterview> GetAllInterviews() {
            return inMemoryDB.Values.ToList();
        }

        IEnumerable<QSaveDeveloperInterview> GetAllInterviewsUsing(String aLanguageName) {
            if (aLanguageName == null)
                throw new Exception("DeveloperInterviewRepository->getAllInterviewsUsing():aLanguageName cannot be null");

            List<QSaveDeveloperInterview> retVal = new List<QSaveDeveloperInterview>();

            foreach (KeyValuePair<String, QSaveDeveloperInterview> developerInterview in inMemoryDB) {

                foreach (var languageSpec in developerInterview.developmentLanguages) {

                    if (String.Equals(languageSpec.name, aLanguageName, StringComparison.OrdinalIgnoreCase)) {
                        retVal.add(developerInterview);
                    }


                }
            }
            return retVal;
        }

        public void AddInterview(QSaveDeveloperInterview anInterview) {
            //: Since dictionary does not allow for duplicate keys
            //: throw an exception if the key already exists
            //: instead use update

            if (anInterview == null)
                throw new Exception("DeveloperInterviewRepository->addInterview(): anInterview cannot be null");

            //: Make sure all values are good values before adding to the repository
            if (!anInterview.isUsable())
                throw new Exception("DeveloperInterviewRepository->addInterview(): anInterview has bad values");

			if (inMemoryDB.ContainsKey(anInterview.interviewID))
                throw new Exception("DeveloperInterviewRepository->addInterview(): anInterview exists, use upDateInterviewUsing() instead");
				
			inMemoryDB.Add(anInterview.interviewID, anInterview);



        }

        public bool UpdateInterviewUsing(QSaveDeveloperInterview anInterview) {

            if (anInterview == null)
                throw new Exception("DeveloperInterviewRepository->updateInterviewUsing(): anInterview cannot be null");

            if (!inMemoryDB.ContainsKey(anInterview.interviewID))
                throw new Exception("DeveloperInterviewRepository->updateInterviewUsing(): interview(" + anInterview.interviewID + ") does not exist");
            //: Make sure all values are good values before adding to the repository\
            if (!anInterview.isUsable())
                throw new Exception("DeveloperInterviewRepository->addInterview()anInterview has bad values");

            inMemoryDB[anInterview.interviewID] = anInterview;

            //: Let the user know it's been updated
            return true;
        }





        public bool DeleteInterviewUsing(String anInterviewID) {
            if (anInterviewID == null)
                throw new Exception("DeveloperInterviewRepository->deleteInterviewUsing(): anInterviewID cannot be null");

            if (anInterviewID.Length == 0)
                throw new Exception("DeveloperInterviewRepository->deleteInterviewUsing(): anInterviewID cannot have 0 length");


            if (!inMemoryDB.ContainsKey(anInterviewID))
                throw new Exception("DeveloperInterviewRepository->deleteInterviewUsing(): interview, anInterviewID, does not exist !11");

            inMemoryDB.Remove(anInterviewID);

            //: I know, I know, either it succeeds, or, an exception is thrown.
            //: I was up in the air about this one. But. It's still some
            //: level of comfort to know that everything went as expected
            return true;//: Signal that the operation was successful
        }


        public QSaveDeveloperInterview GetInterviewUsing(String anInterviewID) {

            if (anInterviewID == null)
                throw new Exception("DeveloperInterviewRepository->getInterviewUsing():anInterviewID cannot be null");

            if (anInterviewID.Length == 0)
					throw new Exception("DeveloperInterviewRepository->getInterviewUsing() : anInterviewID cannot be 0");



            //: If the inMemoryDB conditional is false
            //: throw an exception\
            //: if all is good set the return value, retVal
            //: Then return;\
            if (!inMemoryDB.ContainsKey(anInterviewID))
                throw new Exception("DeveloperInterviewRepository->getInterviewUsing() : interview(" + anInterviewID + ") not found in repository !");

            return inMemoryDB[anInterviewID];




        }


        public void Save() {
            //: This is an inMemoryDB\
            //: Which makes this call, a NoOP
        }
        //: Instantiation at moment of definition
        //: Ensures thread safety\
        private ConcurrentDictionary<String,QSaveDeveloperInterview> inMemoryDB = new ConcurrentDictionary<String, QSaveDeveloperInterview>();



    }



}

