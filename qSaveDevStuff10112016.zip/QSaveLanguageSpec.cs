//: DISCLAIMER. Kevin Citron.\
//: This code has not been tested. I wrote this stuff,after only, 4 hours of \
//: perusing/exploring the world of #C/ASP.WEB\
//: Further more, views were not developed to support this backend code,\
//: Also, this code was written using a TextEditor, TECHNICAL Problems\
//: I'm sure, there are things missing here.\
//: Chris, I'm sure you get the point.\
using System;

namespace QSaveApp.Model
{

    public class QSaveLanguageSpec : IQSaveBaseModel
    {

        public QSaveLanguageSpec(String aLanguageName, int aLengthOfUseYears)
        {
            if (aLanguageName == null)
                throw new Exception("LanguageSpec: aLanguageName cannot be null");
            if (aLengthInYears < 0)
                throw new Exception("LanguageSpec: aLengthInYears cannot be negative");

            this.languageName = aLanguageName;
            this.lengthOfUse = aLengthOfUseYears;
        }

        //: Make sure that we have a usable object
        public bool isUsable()
        {

            if (languageName == null)
                return false;
            if (languageName.Length == 0)
                return false;

            if (lengthOfUse < 0)
                return false;
            return true;
        }
        public String languageName { get; set; }
        public String lengthOfUse { get; set; }
    }
}

