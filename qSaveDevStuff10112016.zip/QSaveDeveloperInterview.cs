//: DISCLAIMER. Kevin Citron.\
//: This code has not been tested. I wrote this stuff,after only, 4 hours of \
//: perusing/exploring the world of #C/ASP.WEB\
//: Further more, views were not developed to support this backend code,\
//: Also, this code was written using a TextEditor, TECHNICAL Problems\
//: I'm sure, there are things missing here.\
//: Chris, I'm sure you get the point.\

using System;
using System.Collections.Generic;

namespace QSaveApp.Model
{
    public class QSaveDeveloperInterview : IQSaveBaseModel
    {


        public String interviewID { get; set; }
        public string candidateName { get; set; }
        public List<LanguageSpec> developmentLanguages = new List<LangauageSpec>();
        public QSaveDeveloperInterview(String anInterviewID, String aCandidateName)
        {
            //: These argument checks could probably 
            //: be refactored into one or more methods
            //: But. I like precision, to know, EXACTLY
            //: What a potential problem is
            if (anInterviewID == null)
                throw new Exception("QSaveDeveloperInterview: anInterviewID, cannot be null");

            if (anInterviewID.Length == 0)
                throw new Exception("QSaveDeveloperInterview: anInterviewID length cannot be 0");

            if (aCandidateName == null)
                throw new Exception("QSaveDeveloperInterview: aCandidateName cannot be null");


            if (aCandidateName.Length == 0)
                throw new Exception("QSaveDeveloperInterview: aCandidateName length cannot be 0");

            interviewID = anInterviewID;
            candidateName = aCandidateName;

        }

        //: This is a double dispatch method\
        //: To ensure that we have a legitimate \
        //: usable object to work with.\
        //: Each object knows, what it means to be\
        //: minimally usable. This method is normally\
        //: used to check before insertion into a \
        //: repository or persistent store\
        public bool isUsable()
        {

            if (interviewID == null)
                return false;

            if (interviewID.Length == 0)
                return false;

            if (candidateID == null)
                return false;

            if (candidateID.Length == 0)
                return false;

            return true;
        }

        public bool addDevelopmentLanguage(LanguageSpec aLanguageSpec)
        {

            if (aLanguageSpec == null)
                throw new Exception("QSaveDeveloperInterview: addDevelopmentLanguage, aLanguageSpec cannot be null");


            if (!aLanguageSpec.isUsable())
                throw new Exception("QSaveDeveloperInterview: addDevelopmentLanguage, aLanguageSpec is not usable, check language name");

            developmentLanguages.Add(aLanguageSpec);
        }


    }
}
