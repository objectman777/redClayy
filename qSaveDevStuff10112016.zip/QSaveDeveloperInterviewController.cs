

using QSaveApp.Model;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.Script.Serialization;

//: DISCLAIMER. Kevin Citron.\
//: This code has not been tested. I wrote this stuff,after only, 4 hours of \
//: perusing/exploring the world of #C/ASP.WEB\
//: Further more, views were not developed to support this backend code,\
//: Also, this code was written using a TextEditor, TECHNICAL Problems\
//: I'm sure, there are things missing here.\
//: Chris, I'm sure you get the point.\

namespace QSaveApp.Controller
{


    [WebService]
    public class QSaveDevelopmentInterviewController : ApiController
    {

        QSaveDevelopmentInterviewController() { }

        //: instantiate the repository\
        //: Which intern instantiates, simulates\
        //: a persistent set of interviewer\
        //: instances



        //: For every publicly exposed 
        //: WebMethod, in the Controller
        //: There is a parallel method defined
        //: by the repository

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public IEnumerable<QSaveDeveloperInterview> GetAllInterviews()
        {
            return new JavaScriptSerializer().Serialize(db.GetAllInterviews());

        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public IEnumerable<QSaveDeveloperInterview> GetAllInterviewsUsing(String aLanguage)
        {
            return new JavaScriptSerializer().Serialize(db.GetAllInterviewsUsing(aLanguage));
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public QSaveDeveloperInterview GetInterviewUsing(String anInterviewID)
        {
            return new JavaScriptSerializer().Serialize(db.GetInterviewUsing(anInterviewID));
        }


        [WebMethod]
        public void AddInterview(String anInterviewID, String aCandidateName)
        {

            db.AddInterview(new QSaveDeveloperInterview(anInterviewID, aCandidateName));

        }

        [WebMethod]
        public void DeleteInterviewUsing(String anInterviewID)
        {
           db.DeleteInterviewUsing(anInterviewID);
        }


        [WebMethod]
        public void Save()
        {
            developerInterviewRepository.Save();
        }

        private void initRepository()
        {
            //: For the sake of brevity
            //: This repository holds one type
            //: of instances. QSaveDeveloperInterview Instances
            //: a Single Key, interviewed ID is used
           


        }
        //: Best place to instantiate. Thread safe, and, guaranteed
        private IDeveloperInterviewRepository db = new DeveloperInterviewRepository();

    }
}
