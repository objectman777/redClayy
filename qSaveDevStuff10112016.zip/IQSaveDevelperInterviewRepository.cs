﻿using System;


public interface IQSaveDeveloperInterviewRepository
{

    public IEnumerable<QSaveDeveloperInterview> GetAllInterviews();
    public IEnumerable<QSaveDeveloperInterview> GetAllInterviewsUsing(String aLanguageName);
    public QSaveDeveloperInterview GetInterviewUsing(String anInterviewID);
    public void AddInterview(QSaveDeveloperInterview anInterview);
    public bool UpdateInterviewUsing(QSaveDeveloperInterview anInterview);
    public bool DeleteInterviewUsing(String anInterviewID);
    public void Save();
        

}




