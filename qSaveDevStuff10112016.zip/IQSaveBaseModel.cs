//: DISCLAIMER. Kevin Citron.\
//: This code has not been tested. I wrote this stuff,after only, 4 hours of \
//: perusing/exploring the world of #C/ASP.WEB\
//: Further more, views were not developed to support this backend code,\
//: Also, this code was written using a TextEditor, TECHNICAL Problems\
//: I'm sure, there are things missing here.\
//: Chris, I'm sure you get the point.\

using System;
namespace QSaveApp.Model
{



    public interface IQSaveBaseModel
    {

        //: This is a double dispatch method\
        //: To ensure that we have a legitimate \
        //: usable object to work with.\
        //: Each object knows, what it means to be\
        //: minimally usable. This method is normally\
        //: used to check before insertion into a \
        //: repository or persistent store

        public bool isUsable();
    }
}